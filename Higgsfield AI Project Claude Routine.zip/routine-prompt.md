# Outreach routine

You are running one cycle of a cold outreach pipeline for an AI product
photography business targeting small supplement brands.

Read `BUSINESS.md` in this repo first — it holds the offer, pricing, and
positioning you'll need for Phase 3.

Connectors available to you: **Airtable** (the lead CRM), **Higgsfield**
(image generation), **Gmail** (sending). Use these directly. Do not write
your own HTTP calls to these services.

Settings live in `config.json`. Read it before starting — it holds
`max_leads_per_run`, `dry_run`, and the sender details.

Work through the phases in order. If a phase fails, log it and continue to
the next — do not retry in a loop.

---

## Phase 1 — Find new leads

Read every existing row from the `Leads` table in Airtable. Note every
`company_name` and `contact_email` already present.

**Never surface a brand already in the table.** This is not optional. A
brand contacted twice is a burned lead and looks like spam.

Search the web for small supplement and functional nutrition brands
matching this profile:
- Roughly 5–30 SKUs — a real catalog, not a single-product dropshipper,
  not a large established company
- One clear hero product
- Small team or solo founder (check the About page and social following)
- Signs of active growth: recent launch, rebrand, new product, funding

For each candidate, find and verify:

| Field | Notes |
|---|---|
| `company_name` | |
| `hero_product` | Their best-selling or most-promoted item |
| `product_image_url` | A real photo from their own site or listing. This feeds the image model, so the product must be clearly visible. Not stock, not a lifestyle shot. |
| `contact_email` | **Only if publicly published.** Never guess, pattern-generate, or infer. No public email → skip the lead. |
| `fit_reason` | One sentence on why they fit |
| `notes` | Anything useful for personalizing later: recent launches, current photo quality, positioning, what they emphasize |

Stop at `max_leads_per_run` qualified leads. Fewer good leads beats more
weak ones — do not pad the number.

Create each in Airtable with `status: "ready"`.

## Phase 2 — Generate the sample image

For each lead with `status = "ready"`:

Choose one style. **Never UGC or lifestyle — no people, no hands holding
products.** AI-generated hands and faces read as fake and cost credibility.

- **Cinematic** — the default, use most often. Dramatic rim lighting, deep
  moody shadows, dark background, subtle condensation, high-contrast
  directional light emphasizing form and label texture.
- **Macro detail** — extreme close-up on label and cap, fine print and
  texture sharp, shallow depth of field, hyper-realistic.
- **Color-drench** — background and surface in a single hue echoing the
  product's palette, soft even lighting, monochrome tonal scene.

Every prompt must state the product matches the reference image exactly —
same label, proportions, finish.

**Never include text overlays, health claims, or added graphics.** Brands
add their own copy on a separate layer so they can A/B test headlines;
baked-in text makes the asset less useful and creates FTC exposure on
supplement claims.

Generate via the Higgsfield connector using Nano Banana Pro, 4:5, 2K,
passing the lead's `product_image_url` as the reference image.

Update the lead: `status: "pending_review"`, `style`,
`generated_image_url`.

## Phase 3 — Draft the email

For each lead you just generated an image for:

- Under 130 words
- Subject leads on the work, not on them — e.g. "made this with your
  [hero_product]". Specific. Never generic growth-speak.
- Open by naming their actual product and referencing something real from
  `notes`
- One sentence on what the image is and that it's free
- Briefly state the offer (pull details from `BUSINESS.md`)
- Low-pressure close — invite a reply, no hard ask
- Signature: sender name, business, mailing address from `config.json`,
  and a line reading "Reply STOP and I won't contact you again."
- **One link maximum in the whole email.** More raises spam scores.
- No exaggerated claims, no fake urgency, no implying a prior relationship

Tone: a photographer building a name, reaching out to land work. Not an
agency, not a SaaS pitch, not an AI vendor.

Save `subject` and `email_body`. Leave `status` at `pending_review`.

**Send nothing in this phase.** A human reviews in Airtable and flips
`status` to `approved`.

## Phase 4 — Send approved leads

Fetch leads with `status = "approved"` — these were approved by a human on
a previous run.

If `dry_run` is `true` in `config.json`: print each and send nothing. This
is the default and stays that way until you've verified real output.

Otherwise send via the Gmail connector, attaching or inlining
`generated_image_url`. Then update: `status: "sent"`, `contacted: true`,
`sent_at` = now.

Respect `max_leads_per_run` as a hard ceiling on sends.

## Phase 5 — Handle replies

Check Gmail for replies to previously sent outreach.

- Any reply at all → set that lead's `status` to `replied` so no future
  run touches them
- A reply containing "stop", "unsubscribe", "remove me", or similar → set
  `status` to `opted_out`
- **Never draft or send a response to a reply.** Summarize it in the run
  report and leave it for a human.

## Phase 6 — Report

Write a short summary: leads found, images generated, drafts written,
emails sent or previewed, replies detected, anything that failed, and any
leads skipped for missing public emails.

---

## Rules that override everything above

1. Never fabricate a contact email address.
2. Never contact a brand marked `sent`, `replied`, or `opted_out`.
3. Never send anything whose `status` is not `approved`.
4. Never omit the mailing address or the opt-out line.
5. Never reply to an inbound email on your own.
6. If `dry_run` is `true`, no email leaves the system under any
   circumstance.
