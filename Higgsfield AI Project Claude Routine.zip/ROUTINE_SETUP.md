# Setting up the routine

The whole pipeline runs as a single Claude Code routine. No GitHub Actions,
no API key, no server. It runs on Claude Code's web infrastructure — your
laptop can be closed.

Routines are in research preview for Pro, Max, Team, and Enterprise plans.

## 1. Build the Airtable base first

The routine can't do anything without somewhere to write. Create a base
with one table named `Leads`:

| Field | Type |
|---|---|
| `company_name` | Single line text |
| `hero_product` | Single line text |
| `product_image_url` | URL |
| `contact_email` | Email |
| `fit_reason` | Long text |
| `notes` | Long text |
| `status` | Single select: `ready`, `pending_review`, `approved`, `sent`, `replied`, `opted_out` |
| `contacted` | Checkbox |
| `style` | Single line text |
| `subject` | Single line text |
| `email_body` | Long text |
| `generated_image_url` | URL |
| `sent_at` | Date |

Create a view filtered to `status = pending_review`. **That view is your
daily job** — you open it, read the drafts, and flip good ones to
`approved`.

## 2. Fill in config.json

Set `sender.mailing_address` to a real physical address. Commercial email
legally requires one. A PO box (~$20/mo) works and keeps your home address
off it.

Leave `dry_run` as `true`.

## 3. Create the routine

In Claude Code (desktop or web):

- **Repo**: `ajoey676/Automated-Health-and-Wellness-Advertisement`
- **Prompt**: `Read agents/routine-prompt.md and follow it.`
- **Connectors**: Airtable, Higgsfield, Gmail
- **Trigger**: Scheduled — weekdays. Start at once daily.

Connectors reach their services through Anthropic's servers, so no network
allowlist changes are needed.

## 4. Test manually before scheduling

Run the routine on demand first. Check in this order — don't move on until
each is right:

1. **Lead quality.** Are these real small supplement brands? Are the emails
   actually published on their sites, or invented? Are the product image
   URLs real product shots? If lead quality is bad, everything downstream
   is worthless.
2. **Images.** Do they look like the actual product? Any text baked in?
   Any mangled hands (shouldn't be — UGC is excluded)?
3. **Drafts.** Read five of them out loud. Do they sound like a
   photographer or like a bot? Is the mailing address and opt-out line
   present on every one?

Tune `agents/routine-prompt.md` and `BUSINESS.md` until all three are
good. That's the whole tuning surface — you shouldn't need to touch code.

## 5. Go live carefully

Once drafts are consistently good:

1. Set `dry_run` to `false`
2. Keep `max_leads_per_run` at 10
3. Run manually once and watch what actually sends
4. Only then enable the schedule

## Quota note

Routines draw from your Claude subscription. A heavy run can throttle your
own interactive sessions in the same window. `max_leads_per_run: 10` keeps
each run modest — raise it only once you know what a run actually costs
you.

## What stays manual, on purpose

- **Approving drafts.** Batch approval takes ~2 minutes a day and catches
  the thing that would otherwise compound silently: a hallucinated product
  detail going out to 30 real business owners with your name on it.
  Revisit full autonomy around month three, once you know the failure
  modes.
- **Replying to interested brands.** The routine flags replies and stops
  contacting them. It never writes back. That conversation is the sale —
  it's yours.
