# Project Brief — AI Supplement Product Photography Outreach

## What this business is

A one-person AI product photography service. I find small supplement brands,
generate a high-end ad image of *their actual product*, and cold-email it as a
free sample. Interested brands buy a photo pack, ideally converting to a
monthly retainer.

Positioning: **a photographer building a name and reaching out to land
clients.** Not a SaaS, not an agency, not an AI tool vendor. The AI is how the
work gets made, not what I'm selling.

## Current status

- Primary venture. Full-time attention as of late August 2026.
- Repo: `ajoey676/Automated-Health-and-Wellness-Advertisement` (private)
- Pipeline scaffolded, two integrations unimplemented (Higgsfield API, sending)
- Nothing has been sent yet. Zero customers.

## Goal

**$1,000 revenue by end of September 2026.** That's 4 starter packs.
Working backward: ~27 replies needed at ~15% close, which is ~800 delivered
emails at a 3.4% reply rate, or ~30/day for 27 days. Achievable, no slack.

## Niche

**Supplements and functional nutrition.** Chosen for 60–80% gross margins
(budget exists), consumable products (real retainer logic), and personal
interest. Beauty was the runner-up; its main edge was UGC performance, which
no longer applies (see below).

## Product and pricing

**Starter — $250**
- 5 final images
- 2–3 style options to choose from before finalizing
- Each delivered in 3 aspect ratios (1:1, 4:5, 9:16)
- One revision round
- 48-hour turnaround
- Full commercial usage rights

**Retainer — $200/month**
- 6 images/month
- Lower per-image than starter, rewards commitment
- Pitched as: "first set $250, then $200/mo to keep creative from going stale"

The 3-aspect-ratio inclusion costs almost nothing and solves a real problem
(feed vs. story vs. Amazon listing). It's what makes $250 feel substantial.

## Image styles — decided

**UGC/lifestyle is excluded.** AI-generated people holding products still read
as wrong (hands, faces, grip). It's the highest-failure-rate style and a bad
image actively costs credibility.

In priority order:
1. **Cinematic** — the hook image in cold emails. Dramatic rim light, deep
   shadows, condensation. Highest "how did you do that" factor because a
   founder cannot replicate it with a phone.
2. **Macro detail** — second strongest. Supplement buyers scrutinize labels
   and ingredient panels; this builds trust.
3. **Color-drench** — scroll-stopping, most "designed" looking.
4. **Minimalist clean studio** — include it (they need it for Amazon), but
   it's not what wins the reply. A founder can approximate it themselves.

**No text overlays baked into images, ever.** Not primarily a compliance
issue — brands need to A/B test headlines on their own layer, so clean
images are the better deliverable. It also avoids FTC substantiation
exposure on health claims.

## Outreach angle

Lead on **transformation, not personalization.** Personalization is table
stakes now that AI made it free. The differentiator is that I send *finished
work made from their actual product*. Subject lines should reflect that
("made this with your [product]").

## Pipeline architecture

Cron-triggered, five stages, in the GitHub repo:

1. **Trigger** — GitHub Actions cron (`workflow_dispatch` for testing)
2. **Research agents** — parallel, one per sub-niche. Find brands, hero
   product, public contact email, product image URL. Must never surface a
   brand already in Airtable. Never fabricate an email address.
3. **Compile/dedup** — merge, filter against Airtable, write `status = ready`
4. **Per-lead Phase A** — generate image (Higgsfield, Nano Banana Pro) +
   draft personalized email → `status = pending_review`
5. **Human batch approval** — I scan drafts in an Airtable view once daily,
   approve in bulk (~2 min)
6. **Per-lead Phase B** — send approved leads from a *prior* run, capped
   per day → `status = sent`

Phase A and B run in the same script but B only touches leads approved
earlier, so nothing can be drafted and sent in one pass.

## Non-negotiables

- Human batch approval before any send (revisit full autonomy ~month 3,
  after I know the agents' failure modes)
- CAN-SPAM footer on every email: real physical address + one-line opt-out
- `DRY_RUN` defaults to true; sends only on explicit `DRY_RUN=false`
- Dedup so no brand is ever emailed twice
- Hard daily send cap
- Any reply (positive or "stop") immediately suppresses that lead
- Research agents never invent contact emails

## Known constraints

- 30–50 emails per inbox per day is the deliverability ceiling
- New inboxes need 6–12 weeks of warm-up
- ~3.4% baseline cold email reply rate; 6–9% for top performers
- Higgsfield: 2 credits per 2K image; Plus plan
- Fulfillment: 48-hour turnaround, handled manually for now

## Budget

~$200/month ceiling. Planned allocation:
- Sending platform (Instantly or Smartlead): ~$37
- Higgsfield Plus: ~$39
- Domain + Google Workspace seat: ~$20
- Airtable: free tier
- Claude API: ~$10–20
- Leaves room for a PO box (~$20) for the CAN-SPAM address

## Strategic context

The image generation skill commoditizes on a 2–4 year horizon — this
capability keeps getting cheaper and will eventually ship inside Shopify.
The durable asset is **the distribution engine**: research → personalize →
generate artifact → outreach → CRM loop. That pipeline is product-agnostic
and transfers to selling anything later.

Treat this business as a real revenue attempt *and* as proof that the
distribution machine works.

## Open items

- Claude API key vs. subscription for the cron loop (API likely correct —
  no reset window, ~$10–20/mo at this volume)
- Physical mailing address for CAN-SPAM footer
- Weekly fulfillment ceiling — unknown how many simultaneous orders is too many
- Whether to buy a sending domain (~$12/yr + $7/mo Workspace) vs. staying on
  a burner Gmail. Burner Gmail can't be SPF/DKIM authenticated, so inbox
  placement is ~50–70%, which likely breaks the September math.
