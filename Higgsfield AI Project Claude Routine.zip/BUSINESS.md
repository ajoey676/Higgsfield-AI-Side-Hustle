# Business context

Read by the outreach routine when drafting emails. Update this file to
change the offer — no need to touch the routine prompt.

## What this is

A one-person AI product photography service for small supplement brands.
Cold outreach leads with a free, finished sample image of the brand's own
hero product.

**Positioning: a photographer building a name, reaching out to land
clients.** Not an agency. Not a SaaS. Not an AI tool vendor. The AI is how
the work gets made, not what's being sold.

## Offer

**Starter — $250**
- 5 final images
- 2–3 style options to choose from before finalizing
- Each delivered in 3 aspect ratios (1:1, 4:5, 9:16)
- One revision round
- 48-hour turnaround
- Full commercial usage rights

**Retainer — $200/month**
- 6 images per month
- Cheaper per image than the starter — rewards commitment
- Framed as: first set $250, then $200/mo to keep creative from going
  stale

The three-aspect-ratio inclusion costs almost nothing to produce and
solves a real problem (feed vs. story vs. Amazon listing). It's what makes
$250 feel substantial.

## Why brands should care

Ad creative decays. Meta and TikTok reward refresh rate, and most small
brands are running the same three photos they shot at launch. The retainer
sells a refresh cadence, not "more pretty pictures."

## What we don't do

- No UGC or lifestyle imagery with people
- No text, claims, or graphics baked into images
- No health claims of any kind in copy or imagery

## Target profile

Small supplement and functional nutrition brands: 5–30 SKUs, one clear
hero product, small team or solo founder, signs of recent growth.
