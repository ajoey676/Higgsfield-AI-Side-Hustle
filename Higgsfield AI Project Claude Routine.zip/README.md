# Automated-Health-and-Wellness-Advertisement

Cold outreach pipeline for an AI product photography service targeting
small supplement brands. Runs as a scheduled Claude Code routine — no
servers, no cron jobs, no API keys.

## How it works

A single routine runs on a schedule and executes six phases:

1. **Research** — finds small supplement brands, dedups against Airtable,
   records hero product, public contact email, and product photo URL
2. **Generate** — creates a cinematic/macro/color-drench ad image of that
   brand's actual product via Higgsfield
3. **Draft** — writes a personalized cold email offering the image free
4. **Send** — sends only leads a human approved on a *previous* run
5. **Replies** — flags any reply and stops contacting that brand
6. **Report** — summarizes the run

Nothing can be drafted and sent in the same run. The approval gate is
enforced by the data flow, not by discipline.

## Files

| File | Purpose |
|---|---|
| `agents/routine-prompt.md` | The routine's instructions — the whole pipeline |
| `BUSINESS.md` | Offer, pricing, positioning. Edit to change the pitch. |
| `config.json` | Run settings: batch size, dry-run flag, sender details |
| `ROUTINE_SETUP.md` | How to create the routine and test it |
| `PROJECT_BRIEF.md` | Full business context and open decisions |

Tuning happens in `routine-prompt.md` and `BUSINESS.md`. There's no
application code to maintain.

## Connectors required

Airtable (CRM), Higgsfield (images), Gmail (sending).

## Safety rules baked in

- Never fabricates a contact email — skips the lead instead
- Never contacts a brand twice
- Human batch approval before any send
- CAN-SPAM footer (physical address + opt-out) on every email
- `dry_run: true` by default — sends nothing until explicitly disabled
- Hard per-run cap on leads and sends
- Never auto-replies to inbound email

## Start here

`ROUTINE_SETUP.md`, step 1.
